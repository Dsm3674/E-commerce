# NexShop — AI-Powered E-Commerce Platform

A premium, fully-animated AI e-commerce site built with **ASP.NET Core 8 (C#)** and a rich HTML/CSS/JS frontend powered by GSAP animations.

---

## Features

### AI-Powered
- **NexAI Chat Assistant** — floating chat widget connected to Claude API for natural language product discovery
- **Hyper-Personalized Feed** — product grid filtered by your Style Quiz profile
- **Smart Cart Recommendations** — AI-powered upsells based on cart contents

### Animations (GSAP + CSS)
- **Scroll Storytelling Hero** — parallax reveal with staggered text animations
- **Magnetic 3D Product Cards** — mouse-tracking tilt with spring physics reset
- **Cinematic Page Elements** — GSAP scroll triggers on every section
- **Infinite Marquee Ticker** — pauses on hover, smooth loop
- **Confetti Checkout** — animated order confirmation

### UX Features
- **Mega Menu** — hover-triggered with live product previews by category
- **Slide-in Cart Drawer** — animated side panel with AI upsells, free shipping tracker
- **Gamified Loyalty System** — XP progress bar, tier badges, Spin-to-Win wheel
- **Dynamic Filter Engine** — instant re-render, no page reload
- **Custom Cursor** — magnetic cursor with hover/click states
- **Live Social Proof Toasts** — timed purchase notifications

### Commerce
- **One-Click Checkout** — multi-step form with payment method selection
- **Wishlist** — heart-to-save with animated feedback
- **Product Compare** — side-by-side comparison bar (up to 2 items)
- **Color Swatches** — inline color selection per product
- **Stock Indicators** — low stock warnings

---

## Project Structure

```
NexShop/
├── Program.cs                  # ASP.NET Core entry point
├── NexShop.csproj
├── appsettings.json
├── Controllers/
│   ├── ProductsController.cs   # GET /api/products, /api/products/{id}, etc.
│   ├── CartController.cs       # Cart CRUD + recommendations
│   └── AiController.cs        # Chat, recommendations, loyalty
├── Models/
│   └── Models.cs               # Product, Cart, CartItem, AiChatRequest, etc.
├── Data/
│   └── SeedData.cs             # 12 seeded products + social proof events
└── wwwroot/
    └── index.html              # Full SPA frontend (GSAP + CSS animations)
```

---

## Setup & Run

### Prerequisites
- [.NET 8 SDK](https://dotnet.microsoft.com/download)

### Install & Run
```bash
cd NexShop
dotnet restore
dotnet run
```

Open: `http://localhost:5000`

Swagger API docs: `http://localhost:5000/swagger`

### Enable AI Chat (Optional)
Add your Anthropic API key to `appsettings.json`:
```json
{
  "Anthropic": {
    "ApiKey": "sk-ant-..."
  }
}
```

Or set the environment variable:
```bash
export ANTHROPIC_API_KEY=sk-ant-...
dotnet run
```

Without a key, the chat assistant falls back to intelligent pre-written responses.

---

## API Endpoints

| Method | Endpoint | Description |
|--------|----------|-------------|
| GET | `/api/products` | List products (filter, sort, search) |
| GET | `/api/products/{id}` | Product detail + related |
| GET | `/api/products/featured` | Featured products |
| GET | `/api/products/trending` | Trending products |
| GET | `/api/products/social-proof` | Social proof events |
| GET | `/api/cart/{sessionId}` | Get cart |
| POST | `/api/cart/{sessionId}/add` | Add item |
| PUT | `/api/cart/{sessionId}/update/{id}` | Update quantity |
| DELETE | `/api/cart/{sessionId}/remove/{id}` | Remove item |
| GET | `/api/cart/{sessionId}/recommendations` | AI cart upsells |
| POST | `/api/ai/chat` | AI shopping assistant chat |
| GET | `/api/ai/recommendations/{productId}` | Product recommendations |
| GET | `/api/ai/loyalty` | Loyalty profile |

---

## Tech Stack

- **Backend:** ASP.NET Core 8, C#, in-memory data store
- **Frontend:** Vanilla JS + HTML5 + CSS3
- **Animations:** GSAP 3.12 (ScrollTrigger, elastic easing, timeline)
- **AI:** Claude claude-sonnet-4-20250514 via Anthropic API
- **Fonts:** Cormorant Garamond (display) + DM Sans (body) + DM Mono
- **Design:** Dark luxury aesthetic — near-black + gold palette

---

## Extending

- **Database:** Replace in-memory `SeedData` + static lists with Entity Framework Core + SQL Server/PostgreSQL
- **Auth:** Add ASP.NET Core Identity for user accounts and persistent wishlists
- **Payments:** Integrate Stripe API in `CheckoutController`
- **Email:** Add order confirmation emails via SendGrid
- **Images:** Replace Unsplash URLs with your own CDN
